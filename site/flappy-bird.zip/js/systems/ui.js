/* UI Updater */
var collisionComponent = require("../components/collision/rect");

var pipeCount = funtion (){
  
}
